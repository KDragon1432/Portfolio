var imgindex = 0;
var images = ["https://pbs.twimg.com/profile_images/773917612648591365/hFl6DSSh.jpg", "https://s-media-cache-ak0.pinimg.com/originals/49/27/de/4927de5adbadbd0043dcc3f08896b2b6.jpg", "https://vignette2.wikia.nocookie.net/disney-infinity/images/e/e6/NemoTop.png/revision/latest?cb=20160520180542"];
function loadImages() {
 document.getElementById("pics").src = images[imgindex];   
}
function left() {
    imgindex--;
    if(imgindex<0){
        imgindex = 2;
    }
    document.getElementById("demo").innerHTML = imgindex;
    loadImages();
}
function right() {
    imgindex++;
    if(imgindex>2){
        imgindex = 0;
    }
    document.getElementById("demo").innerHTML = imgindex;
    loadImages();
}